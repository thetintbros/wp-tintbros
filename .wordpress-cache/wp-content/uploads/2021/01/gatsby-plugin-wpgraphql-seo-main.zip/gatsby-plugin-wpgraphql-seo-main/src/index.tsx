import Seo from './Seo';
import SEOContext from './SeoContext';

export { SEOContext, Seo };

export default Seo;
